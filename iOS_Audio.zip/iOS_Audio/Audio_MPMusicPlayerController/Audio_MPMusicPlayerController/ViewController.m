//
//  ViewController.m
//  Audio_MPMusicPlayerController
//
//  Created by 范云飞 on 2018/3/1.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController ()<MPMediaPickerControllerDelegate>
@property (nonatomic, strong) MPMediaPickerController * mediaPicker;    /* 媒体选择控制器 */
@property (nonatomic, strong) MPMusicPlayerController * musicPlayer;    /* 音乐播放器 */

@property (strong, nonatomic) UIButton * selectBtn;                     /* 选择 */
@property (strong, nonatomic) UIButton * playBtn;                       /* 播放 */
@property (strong, nonatomic) UIButton * pauseBtn;                      /* 暂停 */
@property (strong, nonatomic) UIButton * stopBtn;                       /* 停止播放 */
@property (strong, nonatomic) UIButton * nextBtn;                       /* 下一首 */
@property (strong, nonatomic) UIButton * prevBtn;                       /* 上一首 */
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupUI];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupUI
{
    _selectBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, 100, 80, 30)];
    [_selectBtn setTitle:@"选择" forState:UIControlStateNormal];
    [_selectBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _selectBtn.tag = 0;
    [_selectBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_selectBtn];
    
    _playBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, CGRectGetMaxY(_selectBtn.frame) + 30, 80, 30)];
    [_playBtn setTitle:@"播放" forState:UIControlStateNormal];
    [_playBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _playBtn.tag = 1;
    [_playBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_playBtn];
    
    _pauseBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, CGRectGetMaxY(_playBtn.frame) + 30, 80, 30)];
    [_pauseBtn setTitle:@"暂停" forState:UIControlStateNormal];
    [_pauseBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _pauseBtn.tag = 2;
    [_pauseBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_pauseBtn];
    
    _stopBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, CGRectGetMaxY(_pauseBtn.frame) + 30, 80, 30)];
    [_stopBtn setTitle:@"停止" forState:UIControlStateNormal];
    [_stopBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _stopBtn.tag = 3;
    [_stopBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_stopBtn];
    
    _nextBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, CGRectGetMaxY(_stopBtn.frame) + 30, 80, 30)];
    [_nextBtn setTitle:@"下一首" forState:UIControlStateNormal];
    [_nextBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _nextBtn.tag = 4;
    [_nextBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_nextBtn];
    
    _prevBtn = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 80)/2, CGRectGetMaxY(_nextBtn.frame) + 30, 80, 30)];
    [_prevBtn setTitle:@"上一首" forState:UIControlStateNormal];
    [_prevBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _prevBtn.tag = 5;
    [_prevBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_prevBtn];
}

- (void)click:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        [self presentViewController:self.mediaPicker animated:YES completion:nil];
    }
    if (sender.tag == 1)
    {
        [self.musicPlayer play];
    }
    if (sender.tag == 2)
    {
        [self.musicPlayer pause];
    }
    if (sender.tag == 3)
    {
        [self.musicPlayer stop];
    }
    if (sender.tag == 4)
    {
        [self.musicPlayer skipToNextItem];
    }
    if (sender.tag == 5)
    {
        [self.musicPlayer skipToPreviousItem];
    }
}

/**
 创建音乐播放器

 @return 音乐播放器
 */
- (MPMusicPlayerController *)musicPlayer
{
    if (!_musicPlayer)
    {
        _musicPlayer = [MPMusicPlayerController systemMusicPlayer];
        [_musicPlayer beginGeneratingPlaybackNotifications];//开启通知，否则监控不到MPMusicPlayerController的通知
        [self addNotification];//添加通知
    }
    return _musicPlayer;
}

/**
 创建媒体选择器

 @return 媒体选择器
 */
- (MPMediaPickerController *)mediaPicker
{
    if (!_mediaPicker)
    {
        /* 初始化流媒体选择器，这里设置媒体类型为音乐，其实这里也可以选择视频、广播等 */
//        _mediaPicker = [[MPMediaPickerController alloc]initWithMediaTypes:MPMediaTypeMusic];
        _mediaPicker = [[MPMediaPickerController alloc]initWithMediaTypes:MPMediaTypeAny];
        _mediaPicker.allowsPickingMultipleItems = YES;//允许多选
        _mediaPicker.prompt = @"请选择要播放的音乐";
        _mediaPicker.delegate = self;//设置选择器代理
    }
    return _mediaPicker;
}

/**
 获取媒体队列

 @return 媒体队列
 */
- (MPMediaQuery *)getLocalMediaQuery
{
    MPMediaQuery * mediaQueue = [MPMediaQuery songsQuery];
    for (MPMediaItem * item in mediaQueue.items)
    {
        NSLog(@"标题：%@,%@",item.title,item.albumTitle);
    }
    return mediaQueue;
}

/**
 获取媒体集合

 @return 媒体集合
 */
- (MPMediaItemCollection *)getLocalMediaItemCollection
{
    MPMediaQuery * mediaQueue = [MPMediaQuery songsQuery];
    NSMutableArray * array = [NSMutableArray array];
    for (MPMediaItem * item in mediaQueue.items)
    {
        [array addObject:item];
        NSLog(@"标题：%@,%@",item.title,item.albumTitle);
    }
    MPMediaItemCollection * mediaItemCollection = [[MPMediaItemCollection alloc]initWithItems:[array copy]];
    return mediaItemCollection;
}

#pragma mark - MPMediaPickerControllerDelegate
- (void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
    MPMediaItem * mediaItem = [mediaItemCollection.items firstObject];//第一个播放音乐
    /* 注意很多音乐信息如标题、专辑、表演者、封面、时长等信息都可以通过MPMediaItem的valueForKey：方法得到，但是从iOS7开始都有对应的属性可以直接访问 */
    NSString * title = [mediaItem valueForKey:MPMediaItemPropertyAlbumTitle];
    NSString * artist = [mediaItem valueForKey:MPMediaItemPropertyAlbumArtist];
//    MPMediaItemArtwork * artwork = [mediaItem valueForKey:MPMediaItemPropertyArtwork];
//    UIImage * image = [artwork imageWithSize:CGSizeMake(100, 100)];//专辑图片
    NSLog(@"标题：%@，表演者：%@，专辑：%@",title,artist,mediaItem.albumTitle);
    [self.musicPlayer setQueueWithItemCollection:mediaItemCollection];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 通知
- (void)addNotification
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackStateChange:) name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:self.musicPlayer];
}

- (void)playbackStateChange:(NSNotification *)notification
{
    switch (self.musicPlayer.playbackState)
    {
        case MPMusicPlaybackStatePlaying:
            NSLog(@"正在播放...");
            break;
        case MPMusicPlaybackStatePaused:
            NSLog(@"播放暂停");
            break;
        case MPMusicPlaybackStateStopped:
            NSLog(@"播放停止");
            break;
        default:
            break;
    }
}

- (void)dealloc
{
    [self.musicPlayer endGeneratingPlaybackNotifications];
}

@end
