//
//  ViewController.m
//  AVFoundation_avplayer
//
//  Created by 范云飞 on 2018/3/2.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

#define ScreenWidth      [[UIScreen mainScreen] bounds].size.width
#define ScreenHeight     [[UIScreen mainScreen] bounds].size.height

@interface ViewController ()

@property (nonatomic, strong) AVPlayer * player;            /* 播放器对象 */
@property (nonatomic, strong) UIView * container;           /* 播放器容器 */
@property (nonatomic, strong) UIButton * playOrPause;       /* 播放/暂停按钮 */
@property (nonatomic, strong) UIProgressView * progress;    /* 播放进度 */

@end

@implementation ViewController

#pragma mark - life
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)dealloc{
    
}

#pragma mark - ui
- (void)setupUI{
    /* 创建播放器容器 */
    _container = [[UIView alloc]initWithFrame:CGRectMake(40, 100, ScreenWidth - 80, 200)];
    [self.view addSubview:_container];
    
    /* 创建播放器层 */
    AVPlayerLayer * playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    playerLayer.frame = CGRectMake(0, 0, ScreenWidth - 80, 200);
    [_container.layer addSublayer:playerLayer];
    
    /* 创建播放/暂停按钮 */
    _playOrPause = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMinX(_container.frame), CGRectGetMaxY(_container.frame) + 20, 30, 30)];
    [_playOrPause setImage:[UIImage imageNamed:@"player_pause"] forState:UIControlStateNormal];
    [_playOrPause addTarget:self action:@selector(playClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_playOrPause];
    
    /* 创建进度条 */
    _progress = [[UIProgressView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_playOrPause.frame) + 20, CGRectGetMinY(_playOrPause.frame) + 14, ScreenWidth - 130, 1)];
    [_progress setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_progress];
    
    /* 创建按钮列表 */
    for (int i = 0; i < 3; i++)
    {
        UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(40 + (30 + 20) * i, CGRectGetMaxY(_playOrPause.frame) + 30, 30, 30)];
        [button setBackgroundColor:[UIColor grayColor]];
        [button setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = i;
        [self.view addSubview:button];
    }
}

#pragma mark - notification
/**
 添加播放器通知
 */
- (void)addNotification{
    /* 给AVPlayerItem添加播放完成通知 */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackFinished:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
}

/**
 移除所有通知
 */
- (void)removeNotification{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/**
 视频播放完成通知

 @param notification 通知对象
 */
- (void)playbackFinished:(NSNotification *)notification{
    NSLog(@"视频播放完成");
}

#pragma mark - updateProgress
/**
 给播放器添加进度更新
 */
- (void)addProgressObserver{
    AVPlayerItem * playerItem = self.player.currentItem;
    /* 这里设置美妙执行一次 */
    __weak typeof(self) weakself = self;
    [self.player addPeriodicTimeObserverForInterval:CMTimeMake(1.0, 1.0) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
        float current = CMTimeGetSeconds(time);
        float total = CMTimeGetSeconds([playerItem duration]);
        NSLog(@"当前已经播放：%.2fs",current);
        if (current) {
            [weakself.progress setProgress:(current/total) animated:YES];
        }
    }];
}

#pragma mark - kvo
/**
 给AVPlayerItem添加监控

 @param playerItem AVPlayerItem对象
 */
- (void)addObserverToPlayerItem:(AVPlayerItem *)playerItem{
    /* 监控状态属性，注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态 */
    [playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    /* 监控网络加载情况属性 */
    [playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
}

/**
 去除对AVPlayerItem对象的监听

 @param playerItem AVPlayerItem对象
 */
- (void)removeObserverFromPlayerItem:(AVPlayerItem *)playerItem{
    [playerItem removeObserver:self forKeyPath:@"status"];
    [playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
}

/**
 监控播放器状态

 @param keyPath 监控属性
 @param object 监视器
 @param change 状态改变
 @param context 上下文
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    AVPlayerItem * playerItem = object;
    if ([keyPath isEqualToString:@"status"]) {
        AVPlayerStatus status = [[change objectForKey:@"new"] intValue];
        if (status == AVPlayerStatusReadyToPlay) {
            NSLog(@"正在播放...，视频总长度:%.2f",CMTimeGetSeconds(playerItem.duration));
        }
    }else if ([keyPath isEqualToString:@"loadedTimeRanges"]){
        NSArray * array = playerItem.loadedTimeRanges;
        CMTimeRange timeRange = [array.firstObject CMTimeRangeValue];/* 本次缓冲时间范围 */
        float startSeconds = CMTimeGetSeconds(timeRange.start);
        float durationSeconds = CMTimeGetSeconds(timeRange.duration);
        NSTimeInterval totalBuffer = startSeconds + durationSeconds;/* 缓冲总长度 */
        NSLog(@"共缓冲：%.2f",totalBuffer);
    }
}

#pragma mark - lazy
/**
 创建播放器

 @return 播放器对象
 */
- (AVPlayer *)player{
    if (!_player) {
        AVPlayerItem * playerItem = [self getPlayItem:0];
        _player = [AVPlayer playerWithPlayerItem:playerItem];
        [self addProgressObserver];
        [self addObserverToPlayerItem:playerItem];
    }
    return _player;
}

/**
 根据视频索引取得AVPlayerItem对象

 @param videoIndex 视频顺序索引
 @return AVPlayerItem对象
 */
- (AVPlayerItem *)getPlayItem:(int)videoIndex{
    NSString * urlStr = @"https://media.w3.org/2010/05/sintel/trailer.mp4";
    NSURL * url = [NSURL URLWithString:urlStr];
    AVPlayerItem * playerItem = [AVPlayerItem playerItemWithURL:url];
    return playerItem;
}

#pragma mark - action
- (void)playClick:(UIButton *)sender{
    if (self.player.rate == 0) {
        [sender setImage:[UIImage imageNamed:@"player_play"] forState:UIControlStateNormal];
        [self.player play];
    }else if (self.player.rate == 1){
        [self.player pause];
        [sender setImage:[UIImage imageNamed:@"player_pause"] forState:UIControlStateNormal];
    }
}

- (void)click:(UIButton *)sender{
    [self removeNotification];
    [self removeObserverFromPlayerItem:self.player.currentItem];
    AVPlayerItem * playerItem = [self getPlayItem:(int)sender.tag];
    [self addObserverToPlayerItem:playerItem];
    /* 切换视频 */
    [self.player replaceCurrentItemWithPlayerItem:playerItem];
    [self addNotification];
    [self.player play];
}
@end
