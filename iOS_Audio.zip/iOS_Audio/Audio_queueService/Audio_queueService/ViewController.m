//
//  ViewController.m
//  Audio_queueService
//
//  Created by 范云飞 on 2018/3/1.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import "ViewController.h"
#import "FSAudioStream.h"
#define kMusicFilePath @"张宇 - 雨一直下.mp3"

@interface ViewController ()
@property (nonatomic, strong) FSAudioStream *  audioStream;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton * play = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 80, 30)];
    play.center = self.view.center;
    [play setTitle:@"播放" forState:UIControlStateNormal];
    [play setBackgroundColor:[UIColor blackColor]];
    [play addTarget:self action:@selector(playLocalMusic:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:play];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)playLocalMusic:(UIButton *)sender
{
    [self.audioStream play];
}

/**
 获取本地文件路径

 @return 文件路径
 */
- (NSURL *)getFileUrl{
    NSString * urlStr = [[NSBundle mainBundle]pathForResource:kMusicFilePath ofType:nil];
    NSURL * url = [NSURL fileURLWithPath:urlStr];
    return url;
}

- (NSURL *)getNetworkUrl{
    NSString * urlStr = @"http://sc1.111ttt.cn/2017/1/11/11/304112002072.mp3";
    NSURL * url = [NSURL URLWithString:urlStr];
    return url;
}

- (FSAudioStream *)audioStream{
    if (!_audioStream) {
        NSURL * url = [self getNetworkUrl];
        /* 创建FSAudioStream对象 */
        _audioStream = [[FSAudioStream alloc]initWithUrl:url];
        _audioStream.onFailure = ^(FSAudioStreamError error, NSString *errorDescription) {
            NSLog(@"播放过程中发生错误，错误信息：%@",errorDescription);
        };
        _audioStream.onCompletion = ^{
            NSLog(@"播放完成");
        };
        [_audioStream setVolume:0.5];/* 设置声音 */
    }
    return _audioStream;
}

@end
