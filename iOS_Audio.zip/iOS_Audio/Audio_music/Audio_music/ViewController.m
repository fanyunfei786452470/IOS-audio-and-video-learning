//
//  ViewController.m
//  Audio_music
//
//  Created by 范云飞 on 2018/2/27.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

#define kMusicFile       @"张宇 - 雨一直下.mp3"
#define kMusicSinger     @"张宇"
#define kMusicTitle      @"雨一直下"

@interface ViewController ()<AVAudioPlayerDelegate>
{
    BOOL _isPlaying;    /* 记录当前的播放状态 */
}
@property (strong, nonatomic) AVAudioPlayer * audioPlayer;      /* 播放器 */
@property (strong, nonatomic) UILabel * controlPanel;           /* 控制面板 */
@property (strong, nonatomic) UIProgressView * playProgress;    /* 播放进度 */
@property (strong ,nonatomic) UILabel * musicSigner;            /* 演唱者 */
@property (strong, nonatomic) UIButton * playOrPause;           /* 播放/暂停按钮(如果tag为0认为是暂停状态，1是播放状态) */
@property (strong, nonatomic) NSTimer * timer;                  /* 进度更新定时器 */
@end

@implementation ViewController

/**
 显示当前视图控制器时注册远程时间

 @param animated 是否以动画的形式显示
 */
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    /* 开启远程控制 */
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
}

/**
 当前控制器视图不显示时取消远程控制

 @param animated 是否以动画的形式消失
 */
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = kMusicTitle;
    self.musicSigner.text = kMusicSinger;
    [self setupUI];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


/**
 初始化UI
 */
- (void)setupUI
{
    /* 控制面板 */
    _controlPanel = [[UILabel alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height - 150, self.view.frame.size.width, 150)];
    _controlPanel.backgroundColor = [UIColor grayColor];
    [_controlPanel setUserInteractionEnabled:YES];
    [self.view addSubview:_controlPanel];

    /* 播放进度 */
    _playProgress = [[UIProgressView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, 1)];
    _playProgress.backgroundColor = [UIColor whiteColor];
    [_controlPanel addSubview:_playProgress];
    
    /* 播放或暂停按钮 */
    _playOrPause = [[UIButton alloc]initWithFrame:CGRectMake((self.controlPanel.frame.size.width - 60)/2, 70, 60, 60)];
    [_playOrPause setImage:[UIImage imageNamed:@"playing_btn_play_n"] forState:UIControlStateNormal];
    [_playOrPause addTarget:self action:@selector(playClick:) forControlEvents:UIControlEventTouchUpInside];
    [_controlPanel addSubview:_playOrPause];
}

/**
 点击播放/暂停按钮

 @param sender 播放/暂停按钮
 */
- (void)playClick:(UIButton *)sender
{
    if(_isPlaying)
    {
        [self pause];
    }
    else
    {
        [self play];
    }
    _isPlaying = !_isPlaying;
    [self changeUIState];
}

- (void)changeUIState
{
    if(_isPlaying)
    {
        [_playOrPause setImage:[UIImage imageNamed:@"playing_btn_pause_n"] forState:UIControlStateNormal];
        [_playOrPause setImage:[UIImage imageNamed:@"playing_btn_pause_h"] forState:UIControlStateHighlighted];
    }
    else
    {
        [_playOrPause setImage:[UIImage imageNamed:@"playing_btn_play_n"] forState:UIControlStateNormal];
        [_playOrPause setImage:[UIImage imageNamed:@"playing_btn_play_h"] forState:UIControlStateHighlighted];
    }
}

/**
 播放音频
 */
- (void)play
{
    if (![self.audioPlayer isPlaying])
    {
        [self.audioPlayer play];
        self.timer.fireDate = [NSDate distantPast];//恢复定时器
    }
}

/**
 暂停播放
 */
- (void)pause
{
    if ([self.audioPlayer isPlaying])
    {
        [self.audioPlayer pause];
        self.timer.fireDate = [NSDate distantFuture];//暂停定时器，注意不能调用invalidate方法，此方法会取消，之后无法恢复
    }
}

/**
 初始化定时器

 @return nstimer
 */
- (NSTimer *)timer
{
    if (!_timer)
    {
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateProgress) userInfo:nil repeats:true];
    }
    return _timer;
}

/**
 更新播放进度
 */
- (void)updateProgress
{
    float progress = self.audioPlayer.currentTime / self.audioPlayer.duration;
    [self.playProgress setProgress:progress animated:true];
}

- (AVAudioPlayer *)audioPlayer
{
    if (!_audioPlayer)
    {
        NSString * urlStr = [[NSBundle mainBundle]pathForResource:kMusicFile ofType:nil];
        NSURL * url = [NSURL fileURLWithPath:urlStr];
        NSError * error = nil;
        /* 初始化播放器，注意这里的url参数只能是文件路径，不支持HTTP url */
        _audioPlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:url error:&error];
        /* 设置播放器属性 */
        _audioPlayer.numberOfLoops = 0;//设置为循环一次
        _audioPlayer.delegate = self;
        [_audioPlayer prepareToPlay];//加载音频文件到缓存
        if (error)
        {
            NSLog(@"初始化播放器过程发生错误，错误信息：%@",error.localizedDescription);
            return nil;
        }
        /* 设置后台播放模式 */
        AVAudioSession * audioSession = [AVAudioSession sharedInstance];
        [audioSession setCategory:AVAudioSessionCategoryPlayback error:&error];
        [audioSession setActive:YES error:nil];
        /* 添加通知，拔出耳机后暂停播放 */
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeChange:) name:AVAudioSessionRouteChangeNotification object:nil];
    }
    return _audioPlayer;
}

/**
 一旦输出改变则执行此方法

 @param notification 输出改变通知对象
 */
- (void)routeChange:(NSNotification *)notification
{
    NSDictionary * dic = notification.userInfo;
    int changeReason = [dic[AVAudioSessionRouteChangeReasonKey] intValue];
    if (changeReason == AVAudioSessionRouteChangeReasonOldDeviceUnavailable)
    {
        AVAudioSessionRouteDescription * routeDescription = dic[AVAudioSessionRouteChangePreviousRouteKey];
        AVAudioSessionPortDescription * portDescription = [routeDescription.outputs firstObject];
        /* 原设备为耳机则暂定 */
        if ([portDescription.portType isEqualToString:@"Headphones"])
        {
            [self pause];
        }
    }
}

/**
 销毁通知
 */
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVAudioSessionRouteChangeNotification object:nil];
}

#pragma mark - 远程控制事件
- (void)remoteControlReceivedWithEvent:(UIEvent *)event
{
    NSLog(@"%li,%li",(long)event.type,(long)event.subtype);
    if (event.type == UIEventTypeRemoteControl)
    {
        switch (event.subtype)
        {
            case UIEventSubtypeRemoteControlPlay:
                [self.audioPlayer play];
                self.timer.fireDate = [NSDate distantPast];//恢复定时器
                _isPlaying = true;
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                if (_isPlaying)
                {
                    [self.audioPlayer pause];
                    self.timer.fireDate = [NSDate distantFuture];//暂停定时器，注意不能调用invalidate方法，此方法会取消，之后无法恢复
                }
                else
                {
                    [self.audioPlayer play];
                    self.timer.fireDate = [NSDate distantPast];//恢复定时器
                }
                _isPlaying = !_isPlaying;
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"Nest...");
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"Previous...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"Begin seek forward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"End seek forward...");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"Begin seek backward...");
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"End seek backward...");
                break;
            default:
                break;
        }
        [self changeUIState];
    }
}

#pragma mark - 播放器代理方法
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    NSLog(@"音乐播放完成...");
    /* 根据实际情况播放完成可以将会话关闭，其他音频应用继续播放 */
    [[AVAudioSession sharedInstance] setActive:NO error:nil];
}

@end
