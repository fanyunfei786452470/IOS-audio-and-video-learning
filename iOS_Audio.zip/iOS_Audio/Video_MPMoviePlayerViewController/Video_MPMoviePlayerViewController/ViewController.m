//
//  ViewController.m
//  Video_MPMoviePlayerViewController
//
//  Created by 范云飞 on 2018/3/2.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController ()
/* 播放器视图控制器 */
@property (nonatomic, strong) MPMoviePlayerViewController * moviePlayerViewController;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/**
 初始化UI
 */
- (void)setupUI{
    UIButton * play = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 80, 30)];
    play.center = self.view.center;
    play.backgroundColor = [UIColor blackColor];
    [play addTarget:self action:@selector(playClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:play];
}

- (void)playClick:(UIButton *)sender{
    self.moviePlayerViewController = nil;/* 保证每次点击都重新创建视频播放控制器视图，避免再次点击时由于不播放的问题 */
    [self presentMoviePlayerViewControllerAnimated:self.moviePlayerViewController];
}

/**
 创建播放器

 @return 播放器
 */
- (MPMoviePlayerViewController *)moviePlayerViewController{
    if (!_moviePlayerViewController) {
        NSURL * url = [self getNetworkUrl];
        _moviePlayerViewController = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
        _moviePlayerViewController.moviePlayer.useApplicationAudioSession = NO;//不和系统使用同一个audiosession,这样不受铃音静音的影响
        [self addNotification];
    }
    return _moviePlayerViewController;
}

- (NSURL *)getFileUrl{
    NSString * urlStr = [[NSBundle mainBundle]pathForResource:@"xxx.mp4" ofType:nil];
    NSURL * url = [NSURL fileURLWithPath:urlStr];
    return url;
}

/**
 获取网络文件路径

 @return 文件路劲
 */
- (NSURL *)getNetworkUrl{
    NSString * urlStr = @"https://media.w3.org/2010/05/sintel/trailer.mp4";
    urlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL * url = [NSURL URLWithString:urlStr];
    return url;
}

/**
 添加通知监控媒体播放控制器状态
 */
- (void)addNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(mediaPlayerPlaybackStateChange:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayerViewController.moviePlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(mediaPlayerPlaybackFinished:) name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayerViewController.moviePlayer];
}

/**
 播放状态改变，注意播放完成时状态是暂停

 @param notification 通知对象
 */
- (void)mediaPlayerPlaybackStateChange:(NSNotification *)notification{
    switch (self.moviePlayerViewController.moviePlayer.playbackState) {
        case MPMoviePlaybackStatePlaying:
            NSLog(@"正在播放...");
            break;
        case MPMoviePlaybackStatePaused:
            NSLog(@"暂停播放...");
            break;
        case MPMoviePlaybackStateStopped:
            NSLog(@"停止播放...");
            break;
        default:
            NSLog(@"播放状态：%li",self.moviePlayerViewController.moviePlayer.playbackState);
            break;
    }
}

/**
 播放完成

 @param notification 通知对象
 */
- (void)mediaPlayerPlaybackFinished:(NSNotification *)notification{
    NSLog(@"播放完成：%li",self.moviePlayerViewController.moviePlayer.playbackState);
}

/**
 移除所有通知监控
 */
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
