//
//  AppDelegate.h
//  AVFoundation_avplayer
//
//  Created by 范云飞 on 2018/3/2.
//  Copyright © 2018年 范云飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

